# -*- coding: utf-8 -*-
"""
加载训练好的模型并对有标记样本进行预测和可视化
运行程序，将会生成真实标记图和预测结果图
"""

import os
import sys
import numpy as np
import torch
import torch.nn as nn
import scipy.io as sio
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from collections import defaultdict  # 添加这行导入
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from utils.show_maps import show_pred, color_list
from utils.data_preprocess import padWithZeros, createImageCubes
from models.spikingresformer_step2 import spikingresformer_hsi_step2
from spikingjelly.activation_based import functional, layer
from models.submodules.layers import SpikingMatmul  # 添加这行导入

# 设置设备
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

# 参数设置（需要与训练时一致）
dataset = 'IP'
data_path = os.path.join(os.getcwd(), 'data')
spatial_size = 11
components = 40
class_number = 16
# -------------------------模型结构参数（可调）--------------------------
T = 4                    # 时间步长
num_heads = 8          # 注意力头数（可改为4, 8, 16等）
num_groups = 16           # 分组卷积的分组数（IP/PU用16，SA/HU用32）
use_layerscale = True     # 是否使用LayerScale

model_path ="logs/ip_new/space/space11_step2_head8_group16_t4/Experiment_3/best_model.pth.tar"
# SA数据集的类别名称
class_names = ["Alfalfa", "Corn-notill", "Corn-mintill",
               "Corn", "Grass-pasture", "Grass-trees",
               "Grass-pasture-mowed", "Hay-windrowed", "Oats",
               "Soybean-notill", "Soybean-mintill", "Soybean-clean",
               "Wheat", "Woods", "Buildings-Grass-Trees-Drives",
               "Stone-Steel-Towers"]


# 添加 SOPs 和能量计算工具类
class SOPsEnergyCalculator:
    """计算 SOPs 和能量消耗的工具类"""

    def __init__(self):
        self.sops_dict = defaultdict(float)
        self.hooks = []

    def _conv_hook(self, module, input, output):
        """卷积层的 SOPs 计算"""
        if len(input) == 0:
            return

        # 获取输入和输出形状
        if isinstance(input, (list, tuple)):
            x = input[0]
        else:
            x = input

        if x.dim() != 5:  # [T, B, C, H, W]
            return

        T, B, C_in, H_in, W_in = x.shape
        C_out = output.shape[2]

        # 计算 SOPs
        if hasattr(module, 'kernel_size'):
            if isinstance(module.kernel_size, (list, tuple)):
                kernel_h, kernel_w = module.kernel_size
            else:
                kernel_h = kernel_w = module.kernel_size
        else:
            kernel_h = kernel_w = 1

        if hasattr(module, 'stride'):
            if isinstance(module.stride, (list, tuple)):
                stride_h, stride_w = module.stride
            else:
                stride_h = stride_w = module.stride
        else:
            stride_h = stride_w = 1

        if hasattr(module, 'groups'):
            groups = module.groups
        else:
            groups = 1

        # 获取padding信息
        if hasattr(module, 'padding'):
            if isinstance(module.padding, (list, tuple)):
                padding_h, padding_w = module.padding
            else:
                padding_h = padding_w = module.padding
        else:
            padding_h = padding_w = 0

        # 输出特征图大小
        H_out = (H_in + 2 * padding_h - kernel_h) // stride_h + 1
        W_out = (W_in + 2 * padding_w - kernel_w) // stride_w + 1

        # SOPs = T * B * (C_in/groups * kernel_h * kernel_w) * C_out * H_out * W_out
        sops = T * B * (C_in // groups * kernel_h * kernel_w) * C_out * H_out * W_out
        self.sops_dict['conv'] += sops

    def _linear_hook(self, module, input, output):
        """线性层的 SOPs 计算"""
        if len(input) == 0:
            return

        if isinstance(input, (list, tuple)):
            x = input[0]
        else:
            x = input

        if x.dim() != 3:  # [T, B, features]
            return

        T, B, features_in = x.shape
        features_out = output.shape[2]

        # SOPs = T * B * features_in * features_out
        sops = T * B * features_in * features_out
        self.sops_dict['linear'] += sops

    def _matmul_hook(self, module, input, output):
        """矩阵乘法的 SOPs 计算"""
        if len(input) < 2:
            return

        left, right = input[0], input[1]

        if left.dim() != 5 or right.dim() != 5:
            return

        T, B, _, H_left, W_left = left.shape
        _, _, _, H_right, W_right = right.shape

        # SOPs = T * B * H_left * W_left * W_right
        sops = T * B * H_left * W_left * W_right
        self.sops_dict['matmul'] += sops

    def register_hooks(self, model):
        """为模型注册钩子"""
        for name, module in model.named_modules():
            if isinstance(module, (nn.Conv2d, layer.Conv2d)):
                hook = module.register_forward_hook(self._conv_hook)
                self.hooks.append(hook)
            elif isinstance(module, (nn.Linear, layer.Linear)):
                hook = module.register_forward_hook(self._linear_hook)
                self.hooks.append(hook)
            elif isinstance(module, SpikingMatmul):
                hook = module.register_forward_hook(self._matmul_hook)
                self.hooks.append(hook)

    def remove_hooks(self):
        """移除所有钩子"""
        for hook in self.hooks:
            hook.remove()
        self.hooks = []

    def get_sops(self, batch_size=1):
        """获取总 SOPs"""
        total_sops = sum(self.sops_dict.values())
        # 转换为每张图片的 SOPs
        return total_sops / batch_size if batch_size > 0 else total_sops

    def reset(self):
        """重置计数器"""
        self.sops_dict.clear()


def count_parameters(model):
    """计算模型参数数量"""
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def load_data_with_labels(data_path, name, num_components=None):
    """加载数据集和标签"""
    if name == 'IP':
        data = sio.loadmat(os.path.join(data_path, 'Indian_pines_corrected.mat'))['indian_pines_corrected']
        labels = sio.loadmat(os.path.join(data_path, 'Indian_pines_gt.mat'))['indian_pines_gt']
    else:
        print("不支持的数据库")
        exit()

    # 保存原始形状和标签
    original_shape = data.shape
    original_labels = labels

    # 数据预处理（与训练时一致）
    data = data.reshape(-1, data.shape[-1])
    if num_components != None:
        data = PCA(n_components=num_components).fit_transform(data)
    data = StandardScaler().fit_transform(data)
    data = data.reshape(original_shape[0], original_shape[1], -1)

    return data, original_labels


def predict_labeled_samples(model, data, labels, windowSize=5, calculator=None):
    """只对有标记的样本进行预测，并计算 SOPs 和能量"""
    # 获取有标记的像素位置
    labeled_positions = np.where(labels > 0)
    labeled_coords = list(zip(labeled_positions[0], labeled_positions[1]))

    # 对图像进行padding
    margin = int((windowSize - 1) / 2)
    zeroPaddedX = padWithZeros(data, margin=margin)

    # 创建预测结果矩阵（初始为0，表示背景）
    pred_map = np.zeros_like(labels)

    # 设置为评估模式
    model.eval()

    # 重置计算器
    if calculator:
        calculator.reset()

    # 批量处理以提高效率
    batch_size = 64
    num_batches = (len(labeled_coords) + batch_size - 1) // batch_size

    total_sops = 0
    processed_images = 0

    with torch.no_grad():
        for i in range(num_batches):
            batch_coords = labeled_coords[i * batch_size: (i + 1) * batch_size]
            batch_patches = []

            # 提取批量中的图像块
            for r, c in batch_coords:
                # 提取图像块（考虑padding）
                patch = zeroPaddedX[r: r + 2 * margin + 1, c: c + 2 * margin + 1, :]
                patch = np.transpose(patch, (2, 0, 1)).astype("float32")
                batch_patches.append(patch)

            # 转换为张量
            batch_tensor = torch.from_numpy(np.array(batch_patches)).to(device)

            # 重置网络状态
            functional.reset_net(model)

            # 对于最后一个批次，如果大小不匹配，使用动态调整
            actual_batch_size = len(batch_coords)
            if batch_tensor.size(0) != batch_size:
                # 创建一个与模型期望大小匹配的新张量
                padded_batch = torch.zeros(batch_size, *batch_tensor.shape[1:], device=device)
                padded_batch[:actual_batch_size] = batch_tensor
                batch_tensor = padded_batch

            # 预测
            outputs = model(batch_tensor)

            # 计算 SOPs
            if calculator:
                batch_sops = calculator.get_sops(batch_size=actual_batch_size)
                total_sops += batch_sops * actual_batch_size
                processed_images += actual_batch_size
                calculator.reset()

            # 只取实际存在的样本的预测结果
            predictions = torch.argmax(outputs[:actual_batch_size], dim=1).cpu().numpy()

            # 将预测结果填充到对应位置
            for j, (r, c) in enumerate(batch_coords):
                pred_map[r, c] = predictions[j] + 1  # 加1是为了与原始标签一致（原始标签从1开始）

    # 计算平均值
    avg_sops = total_sops / processed_images if processed_images > 0 else 0

    # 按照main.py的方法计算能量：0.9 * SOPs (mJ)
    # SOPs转换为G单位，然后乘以0.9得到能量(mJ)
    avg_sops_g = avg_sops / 1e9  # 转换为G单位
    avg_energy = 0.9 * avg_sops_g  # 能量计算：0.9 * SOPs (mJ)

    return pred_map, avg_sops, avg_energy


def show_gt_map(labels, class_nums, save_path, dataset_name):
    """显示真实标记图，不带图例"""
    colors = color_list(class_nums)
    colors = colors / 255.0  # 归一化到0-1范围

    # 创建专题地图
    gt_thematic_map = np.zeros((labels.shape[0], labels.shape[1], 3))

    # 为每个类别分配颜色
    for i in range(labels.shape[0]):
        for j in range(labels.shape[1]):
            if labels[i, j] > 0:
                gt_thematic_map[i, j, :] = colors[labels[i, j]]

    # 绘制图像，不带图例
    plt.figure(figsize=(10, 10))
    plt.imshow(gt_thematic_map)
    plt.axis('off')
    plt.tight_layout()

    # 保存图像
    plt.savefig(os.path.join(save_path, f'ground_truth_{dataset_name}.png'), bbox_inches='tight', dpi=300)
    plt.close()


def create_legend_figure(class_nums, class_names, save_path, dataset_name):
    """创建单独的图例图，2行5列"""
    colors = color_list(class_nums)
    colors = colors / 255.0  # 归一化到0-1范围

    # 创建图例
    patches = [mpatches.Patch(color=colors[i], label=f"{i}: {class_names[i - 1]}") for i in range(1, len(colors))]

    # 创建新图形，设置大小为适应2行5列的图例
    fig = plt.figure(figsize=(12, 5))

    # 添加图例，设置为2行5列
    plt.legend(handles=patches, ncol=5, loc='center', frameon=False)
    plt.axis('off')  # 关闭坐标轴

    # 调整布局并保存
    plt.tight_layout()
    plt.savefig(os.path.join(save_path, f'legend_{dataset_name}.png'), bbox_inches='tight', dpi=300)
    plt.close()


def main():
    # 加载数据
    print("加载数据...")
    data, labels = load_data_with_labels(data_path, dataset, components)

    # 显示真实标记图（不带图例）
    print("生成真实标记图...")
    save_path = os.path.dirname(model_path)
    show_gt_map(labels, class_number, save_path, dataset)
    print(f"真实标记图已保存到: {os.path.join(save_path, f'ground_truth_{dataset}.png')}")

    # 生成单独的图例图
    print("生成图例图...")
    create_legend_figure(class_number, class_names, save_path, dataset)
    print(f"图例图已保存到: {os.path.join(save_path, f'legend_{dataset}.png')}")

    # 加载模型
    print("加载模型...")
    model = spikingresformer_hsi_step2(
        num_heads=num_heads,
        T=T,
        num_classes=class_number,
        img_size=spatial_size,
        in_channels=components,
        num_groups=num_groups,
        use_layerscale=use_layerscale
    )
    model = model.to(device)

    # 加载训练好的权重
    checkpoint = torch.load(model_path)
    model.load_state_dict(checkpoint['state_dict'])
    print(f"加载模型完成，最佳准确率: {checkpoint['best_acc']}")

    # 计算参数数量
    total_params = count_parameters(model)
    #print(f"模型参数数量: {total_params / 1e6:.2f}M")
    print(f"模型参数数量: {total_params:}")
    # 创建 SOPs 和能量计算器
    calculator = SOPsEnergyCalculator()
    calculator.register_hooks(model)

    # 只对有标记的样本进行预测
    print("开始预测有标记的样本...")
    pred_labeled, avg_sops, avg_energy = predict_labeled_samples(
        model, data, labels, windowSize=spatial_size, calculator=calculator
    )

    # 移除钩子
    calculator.remove_hooks()

    # 输出结果 - 按照main.py的格式
    print(f"参数数量: {total_params / 1e6:.2f}M")
    print(f"平均 SOPs 每图像: {avg_sops / 1e9:.5f}G")
    print(f"平均能量消耗每图像: {avg_energy:.5f}mJ")

    # 保存结果到文件
    results_file = os.path.join(save_path, 'model_metrics.txt')
    with open(results_file, 'w') as f:
        f.write(f"Model: SpikingResformer-HSI\n")
        f.write(f"Dataset: {dataset}\n")
        f.write(f"Parameters: {total_params / 1e6:.2f}M\n")
        f.write(f"SOPs per image: {avg_sops / 1e9:.5f}G\n")
        f.write(f"Energy per image: {avg_energy:.5f}mJ\n")
        f.write(f"Best Accuracy: {checkpoint['best_acc']:.4f}\n")

    # 展示预测结果
    print("生成预测图...")
    show_pred(pred_labeled, labels, class_number, dataset, save_path, removeZeroLabels=True)
    print(f"预测图已保存到: {save_path}")

    # 计算准确率
    labeled_indices = labels > 0
    accuracy = np.sum(pred_labeled[labeled_indices] == labels[labeled_indices]) / np.sum(labeled_indices)
    print(f"有标记样本的预测准确率: {accuracy:.4f}")

    # 显示每个类别的准确率
    print("\n各类别准确率:")
    for i in range(1, class_number + 1):
        class_indices = (labels == i)
        if np.any(class_indices):
            class_accuracy = np.sum(pred_labeled[class_indices] == labels[class_indices]) / np.sum(class_indices)
            print(f"{class_names[i - 1]}: {class_accuracy:.4f}")

    print("完成!")


if __name__ == '__main__':
    main()