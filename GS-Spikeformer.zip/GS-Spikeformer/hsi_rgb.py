import scipy.io
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap

# 加载.mat文件
mat_data = scipy.io.loadmat('./data/PaviaU_gt.mat')

# 获取数据 - 需要根据实际MAT文件结构调整键名
# 通常地物分类数据的键名可能是'paviaU_gt', 'gt', 或'label'等
# 你可以打印mat_data.keys()查看所有可用的键
print("Available keys in the .mat file:", mat_data.keys())

# 假设地物分类数据的键名为'paviaU_gt'
gt_data = mat_data['paviaU_gt']  # 可能需要根据实际情况修改键名

# 定义类别颜色映射
# 这里为PaviaU数据集的9个类别定义不同的颜色
colors = [
    [0, 0, 0],          # 0: 背景 - 黑色
    [255, 0, 0],        # 1: Asphalt - 红色
    [0, 255, 0],        # 2: Meadows - 绿色
    [0, 0, 255],        # 3: Gravel - 蓝色
    [255, 255, 0],      # 4: Trees - 黄色
    [255, 0, 255],      # 5: Painted metal sheets - 洋红色
    [0, 255, 255],      # 6: Bare Soil - 青色
    [255, 128, 0],      # 7: Bitumen - 橙色
    [128, 0, 255],      # 8: Self-Blocking Bricks - 紫色
    [128, 128, 128]     # 9: Shadows - 灰色
]

# 创建RGB图像
height, width = gt_data.shape
rgb_image = np.zeros((height, width, 3), dtype=np.uint8)

# 将每个类别映射到对应的颜色
for i in range(height):
    for j in range(width):
        class_id = gt_data[i, j]
        if class_id < len(colors):
            rgb_image[i, j] = colors[class_id]

# 显示图像
plt.figure(figsize=(10, 8))
plt.imshow(rgb_image)
plt.title('PaviaU Ground Truth')
plt.axis('off')

# 添加图例
from matplotlib.patches import Patch
legend_elements = [
    Patch(facecolor=np.array(color)/255, label=f'Class {i}')
    for i, color in enumerate(colors) if i > 0  # 跳过背景类
]
plt.legend(handles=legend_elements, bbox_to_anchor=(1.05, 1), loc='upper left')

plt.tight_layout()
plt.savefig('PaviaU_gt_rgb.png', bbox_inches='tight', dpi=300)
plt.show()

print("RGB图像已保存为 'PaviaU_gt_rgb.png'")