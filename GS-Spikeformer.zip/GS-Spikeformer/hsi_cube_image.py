import numpy as np
import matplotlib.pyplot as plt
from scipy.io import loadmat

# 加载MAT文件
data = loadmat('PaviaU.mat')

# 查找包含图像数据的变量
# 通常在高光谱数据集中，数据存储在名为'paviaU'或类似名称的变量中
# 我们先查看文件中的所有变量名
print("文件中的变量:", [key for key in data.keys() if not key.startswith('__')])

# 假设图像数据存储在名为'paviaU'的变量中
# 如果没有，可能需要尝试其他可能的名称如'data', 'image', 'img'等
if 'paviaU' in data:
    image_data = data['paviaU']
else:
    # 尝试找到包含图像数据的变量
    for key in data.keys():
        if not key.startswith('__'):
            if hasattr(data[key], 'shape') and len(data[key].shape) >= 2:
                image_data = data[key]
                print(f"使用变量 '{key}' 作为图像数据")
                break
    else:
        raise ValueError("未找到图像数据")

# 检查数据的形状
print("图像数据形状:", image_data.shape)

# 高光谱图像通常是3维的 (height, width, bands)
# 我们需要选择一个或多个波段来显示
if len(image_data.shape) == 3:
    # 显示第一个波段
    plt.figure(figsize=(10, 8))
    plt.imshow(image_data[:, :, 0], cmap='gray')
    plt.title('PaviaU - 波段 1')
    plt.colorbar()
    plt.show()

    # 创建RGB合成图像（假设波段50、30、10分别对应R、G、B）
    if image_data.shape[2] >= 50:
        rgb_image = np.stack([
            image_data[:, :, 49],  # 红色通道（波段50）
            image_data[:, :, 29],  # 绿色通道（波段30）
            image_data[:, :, 9]  # 蓝色通道（波段10）
        ], axis=2)

        # 归一化到0-1范围
        rgb_image = (rgb_image - np.min(rgb_image)) / (np.max(rgb_image) - np.min(rgb_image))

        plt.figure(figsize=(10, 8))
        plt.imshow(rgb_image)
        plt.title('PaviaU - RGB合成图像（波段50,30,10）')
        plt.show()
    else:
        print("数据没有足够的波段来创建RGB图像")
else:
    # 如果是2维数据，直接显示
    plt.figure(figsize=(10, 8))
    plt.imshow(image_data, cmap='gray')
    plt.title('PaviaU图像')
    plt.colorbar()
    plt.show()