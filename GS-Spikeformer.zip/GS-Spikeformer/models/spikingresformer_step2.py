# 第2步：改进版GSSA - 移除运行平均发放率，使用固定常数缩放 + LayerScale
# 支持从主程序传入 num_heads 和 num_groups
import math
import torch
import torch.nn as nn
from .submodules.layers import Conv3x3, Conv1x1, LIF, PLIF, BN, Linear, SpikingMatmul
from spikingjelly.activation_based import layer
from typing import Any, List, Mapping
from timm.models.registry import register_model


class SpectralCalibration(nn.Module):
    """Spectral Calibration Block from GSC-ViT"""

    def __init__(self, dim_in, dim_out, activation=LIF):
        super().__init__()
        self.conv = layer.Conv2d(dim_in, dim_out, 1, 1, 0, bias=False, step_mode='m')
        self.norm = BN(dim_out)
        self.activation = activation()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.conv(x)
        x = self.norm(x)
        x = self.activation(x)
        return x


class GWFFN(nn.Module):
    def __init__(self, in_channels, num_conv=1, ratio=4, group_size=64, activation=LIF):
        super().__init__()
        inner_channels = in_channels * ratio
        self.up = nn.Sequential(
            activation(),
            Conv1x1(in_channels, inner_channels),
            BN(inner_channels),
        )
        self.conv = nn.ModuleList()
        for _ in range(num_conv):
            self.conv.append(
                nn.Sequential(
                    activation(),
                    Conv3x3(inner_channels, inner_channels, groups=inner_channels // group_size),
                    BN(inner_channels),
                ))
        self.down = nn.Sequential(
            activation(),
            Conv1x1(inner_channels, in_channels),
            BN(in_channels),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x_feat_out = x.clone()
        x = self.up(x)
        x_feat_in = x.clone()
        for m in self.conv:
            x = m(x)
        x = x + x_feat_in
        x = self.down(x)
        x = x + x_feat_out
        return x


class LayerScale(nn.Module):
    """可学习的LayerScale，帮助训练稳定性"""
    def __init__(self, dim, init_values=1e-5):
        super().__init__()
        self.gamma = nn.Parameter(init_values * torch.ones(dim, 1, 1))

    def forward(self, x):
        return x * self.gamma


class GSSA(nn.Module):
    """改进版Groupwise Separable Self-Attention (GSSA)
       - 移除运行平均发放率，使用固定常数缩放（标准Transformer方式）
       - 添加LayerScale提升表示能力
       - 优化分组卷积的分组数确保整除
    """

    def __init__(self, dim, num_heads, lenth, patch_size, num_groups=8, activation=LIF, use_layerscale=True):
        super().__init__()
        assert dim % num_heads == 0, f"dim {dim} should be divided by num_heads {num_heads}."
        self.dim = dim
        self.num_heads = num_heads
        self.lenth = lenth
        self.num_groups = num_groups
        self.use_layerscale = use_layerscale

        # 固定缩放因子（标准Transformer缩放）
        self.scale1 = 1.0 / math.sqrt(dim // num_heads)
        self.scale2 = 1.0 / math.sqrt(lenth)

        self.activation_in = activation()

        # 使用单个卷积生成Q, K, V（保持与DSSA相同）
        self.W = layer.Conv2d(dim, dim * 2, patch_size, patch_size, bias=False, step_mode='m')
        self.norm = BN(dim * 2)

        # 分组投影 - 确保分组数不超过通道数且能整除
        effective_groups = min(self.num_groups, dim)
        for g in range(effective_groups, 0, -1):
            if dim % g == 0:
                effective_groups = g
                break
        self.effective_groups = effective_groups

        self.Wproj = layer.Conv2d(dim, dim, 1, 1, 0, groups=effective_groups, bias=False, step_mode='m')
        self.norm_proj = BN(dim)

        # LayerScale
        if use_layerscale:
            self.layerscale = LayerScale(dim)
        else:
            self.layerscale = nn.Identity()

        self.matmul1 = SpikingMatmul('r')
        self.matmul2 = SpikingMatmul('r')
        self.activation_attn = activation()
        self.activation_out = activation()

        print(f"GSSA初始化: dim={dim}, num_heads={num_heads}, num_groups={effective_groups}")

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # X: [T, B, C, H, W]
        T, B, C, H, W = x.shape
        x_feat = x.clone()
        x = self.activation_in(x)

        # 生成Q, K, V
        y = self.W(x)
        y = self.norm(y)
        y = y.reshape(T, B, self.num_heads, 2 * C // self.num_heads, -1)
        y1, y2 = y[:, :, :, :C // self.num_heads, :], y[:, :, :, C // self.num_heads:, :]
        x_reshaped = x.reshape(T, B, self.num_heads, C // self.num_heads, -1)

        # 注意力计算：使用固定常数缩放
        attn = self.matmul1(y1.transpose(-1, -2), x_reshaped)
        attn = attn * self.scale1
        attn = self.activation_attn(attn)

        # 输出聚合：使用固定常数缩放
        out = self.matmul2(y2, attn)
        out = out * self.scale2
        out = out.reshape(T, B, C, H, W)
        out = self.activation_out(out)

        # 分组投影 + LayerScale + 残差
        out = self.Wproj(out)
        out = self.norm_proj(out)
        out = self.layerscale(out)
        out = out + x_feat
        return out


class DownsampleLayer(nn.Module):
    def __init__(self, in_channels, out_channels, stride=2, activation=LIF) -> None:
        super().__init__()
        self.conv = Conv3x3(in_channels, out_channels, stride=stride)
        self.norm = BN(out_channels)
        self.activation = activation()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.activation(x)
        x = self.conv(x)
        x = self.norm(x)
        return x


class SpikingResformerStep2(nn.Module):
    def __init__(
            self,
            layers: List[List[str]],
            planes: List[int],
            num_heads: List[int],
            patch_sizes: List[int],
            img_size=224,
            T=4,
            in_channels=3,
            num_classes=1000,
            prologue=None,
            num_groups=8,
            use_layerscale=True,
            activation=LIF,
            **kwargs,
    ):
        super().__init__()
        self.T = T
        self.skip = ['prologue.0', 'classifier']
        assert len(planes) == len(layers) == len(num_heads) == len(patch_sizes)

        # Add Spectral Calibration
        self.spectral_calibration = SpectralCalibration(in_channels, 256, activation=activation)

        if prologue is None:
            self.prologue = nn.Sequential(
                layer.Conv2d(256, planes[0], 3, 1, 1, bias=False, step_mode='m'),
                BN(planes[0]),
            )
            img_size = img_size
        else:
            self.prologue = prologue

        self.layers = nn.Sequential()
        for idx in range(len(planes)):
            sub_layers = nn.Sequential()
            if idx != 0 and img_size >= 8:
                sub_layers.append(
                    DownsampleLayer(planes[idx - 1], planes[idx], stride=2, activation=activation))
                img_size = img_size // 2
            for name in layers[idx]:
                if name == 'GSSA':
                    current_patch_size = min(patch_sizes[idx], img_size)
                    sub_layers.append(
                        GSSA(planes[idx], num_heads[idx], (img_size // current_patch_size) ** 2,
                             current_patch_size, num_groups=num_groups, activation=activation,
                             use_layerscale=use_layerscale))
                elif name == 'GWFFN':
                    sub_layers.append(
                        GWFFN(planes[idx], group_size=64, activation=activation))
                else:
                    raise ValueError(name)
            self.layers.append(sub_layers)

        self.avgpool = layer.AdaptiveAvgPool2d((1, 1), step_mode='m')
        self.classifier = Linear(planes[-1], num_classes)
        self.init_weight()

    def init_weight(self):
        for m in self.modules():
            if isinstance(m, (nn.Linear, nn.Conv2d)):
                nn.init.trunc_normal_(m.weight, std=0.02)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.dim() != 5:
            x = x.unsqueeze(0).repeat(self.T, 1, 1, 1, 1)
            assert x.dim() == 5
        else:
            x = x.transpose(0, 1)

        x = self.spectral_calibration(x)
        x = self.prologue(x)
        x = self.layers(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 2)
        x = self.classifier(x)
        x = x.mean(0)
        return x


@register_model
def spikingresformer_hsi_step2(num_heads=8, **kwargs):
    """
    改进版：移除不稳定的运行平均发放率，使用固定常数缩放 + LayerScale
    新增 num_heads 参数，允许从主程序指定注意力头数
    """
    in_channels = kwargs.get('in_channels', 3)
    if 'in_channels' in kwargs:
        kwargs = kwargs.copy()
        del kwargs['in_channels']

    num_groups = kwargs.pop('num_groups', 32)
    use_layerscale = kwargs.pop('use_layerscale', True)

    # 确保 num_heads 是列表格式
    if not isinstance(num_heads, list):
        num_heads = [num_heads]

    return SpikingResformerStep2(
        [
            ['GSSA', 'GWFFN'] * 1,
        ],
        [64],
        num_heads,
        [1],
        in_channels=in_channels,
        num_groups=num_groups,
        use_layerscale=use_layerscale,
        prologue=nn.Sequential(
            layer.Conv2d(256, 64, 3, 1, 1, bias=False, step_mode='m'),
            BN(64),
            layer.MaxPool2d(kernel_size=2, stride=1, padding=0, step_mode='m'),
        ),
        **kwargs,
    )