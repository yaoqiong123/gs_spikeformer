# -*- coding: utf-8 -*-
"""
@CreatedDate:   2020/4/27 12:08
@Author: Pangpd(https://github.com/pangpd/DS-pResNet-HSI)
@UsedBy: Katherine_Cao(https://github.com/Katherine-Cao/HSI_SNN)
Modified: 增加对模型超参数（heads, groups, T, LayerScale）的记录，所有参数均可从主程序指定
"""
import os
import sys
import time
from utils.auxiliary import save_acc_loss
from utils.data_preprocess import load_hyper
from utils.auxiliary import get_logger
from utils.hyper_pytorch import *
from datetime import datetime
import torch
import torch.nn.parallel
import warnings
warnings.filterwarnings('ignore')
from utils.evaluate import reports, stats
from utils.start import test, train, predict

from models.spikingresformer_step2 import spikingresformer_hsi_step2, GSSA

np.set_printoptions(linewidth=400)
np.set_printoptions(threshold=sys.maxsize)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

# -------------------------定义超参数--------------------------
data_path = os.path.join(os.getcwd(), 'data')

dataset = 'IP'
seed = 1014
nums_repeat = 10
epochs = 100
spatial_size = 11
train_samples = 100
train_percent = 0.75
batch_size = 64
components = 40
learn_rate = 0.0085
momentum = 0.9
weight_decay = 0.0001
use_val = True
class_number = 16

# -------------------------模型结构参数（可调）--------------------------
T = 4                    # 时间步长
num_heads = 8           # 注意力头数（可改为4, 8, 16等）
num_groups =32           # 分组卷积的分组数（IP/PU用16，SA/HU用32）
use_layerscale = True     # 是否使用LayerScale

def count_parameters(model):
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return total_params, trainable_params

def extract_model_config(model):
    """从模型中提取实际的 heads, dim, groups 等配置"""
    for module in model.modules():
        if isinstance(module, GSSA):
            return {
                'dim': module.dim,
                'heads': module.num_heads,
                'effective_groups': module.effective_groups,
                'lenth': module.lenth,
            }
    return None

def main():
    # 先临时创建一个模型，提取真实配置（heads, effective_groups等），用于最终日志
    with torch.no_grad():
        temp_model = spikingresformer_hsi_step2(
            num_heads=num_heads,
            T=T,
            num_classes=class_number,
            img_size=spatial_size,
            in_channels=components,
            num_groups=num_groups,
            use_layerscale=use_layerscale
        )
        temp_model_config = extract_model_config(temp_model)
        del temp_model
        torch.cuda.empty_cache()

    time_str = datetime.strftime(datetime.now(), '%m-%d_%H-%M-%S')
    log_path = os.path.join(os.getcwd(), "logs")
    log_dir = os.path.join(log_path, time_str)

    oa_list = []
    aa_list = []
    kappa_list = []
    each_acc_list = []
    train_time_list = []
    test_time_list = []
    for iter in range(nums_repeat):
        torch.cuda.empty_cache()
        group_log_dir = os.path.join(log_dir, "Experiment_" + str(iter + 1))
        if not os.path.exists(group_log_dir):
            os.makedirs(group_log_dir)
        group_logger = get_logger(str(iter + 1), group_log_dir)
        random_state = seed + iter
        print('-------------------------------------------Iter %s----------------------------------' % (iter + 1))
        oa, aa, kappa, each_acc, train_time, test_time = start(group_log_dir, random_state, logger=group_logger)
        print("oa:", oa, "aa:", aa, "kappa:", kappa, "each_acc:", each_acc, "train_time:", train_time, "test_time:", test_time)
        oa_list.append(oa)
        aa_list.append(aa)
        kappa_list.append(kappa)
        each_acc_list.append(each_acc)
        train_time_list.append(train_time)
        test_time_list.append(test_time)

    stats_oa, stats_aa, stats_kappa, stats_each_acc, stats_train_time, \
    stats_test_time = stats(oa_list, aa_list, kappa_list, each_acc_list, train_time_list, test_time_list)

    stats_logger = get_logger('final', log_dir)
    config_str = f'''
             dataset:         {dataset}
             Epochs:          {epochs}
             spatial size:    {spatial_size}
             components:      {components}
             batch size:      {batch_size}
             Learning rate:   {learn_rate}
             momentum:        {momentum}
             weight decay:    {weight_decay}       
             train sample:    {train_samples}
             train percent:   {train_percent}
             use validSet:    {use_val}
             class number：   {class_number}
             Time steps T:    {T}
             Heads (input):   {num_heads}
             Groups (input):  {num_groups}
             LayerScale:      {use_layerscale}
    '''
    if temp_model_config is not None:
        config_str += f'''
             Actual heads:     {temp_model_config['heads']}
             Actual dim:       {temp_model_config['dim']}
             Actual groups:    {temp_model_config['effective_groups']}
             Length N:         {temp_model_config['lenth']}
        '''
    stats_logger.debug(config_str)

    stats_logger.info('------------------------------------本组实验结果---------------------------------------------------')
    stats_logger.info("OA均值:%f   总体标准差:%f   样本标准差:%f" %
                      (stats_oa['av_oa'], stats_oa['ov_std_oa'], stats_oa['samp_std_oa']))
    stats_logger.info("AA均值:%f   总体标准差:%f   样本标准差:%f " %
                      (stats_aa['av_aa'], stats_aa['ov_std_aa'], stats_aa['samp_std_aa']))
    stats_logger.info("kappa均值:%f  总体标准差:%f   样本标准差:%f" %
                      (stats_kappa['av_kappa'], stats_kappa['ov_std_kappa'], stats_kappa['samp_std_kappa']))
    stats_logger.info("每类地物分类均值:      %s" % (stats_each_acc['av_each_acc']))
    stats_logger.info("每类地物分类总体标准差:%s" % (stats_each_acc['ov_std_each_acc']))
    stats_logger.info("每类地物分类样本标准差:%s" % (stats_each_acc['samp_std_each_acc']))
    stats_logger.info("训练时间均值:%f  总体标准差:%f  样本标准差:%f;  测试时间均值:%f  总体标准差:%f     样本标准差:%f" % (
        stats_train_time['av_train_time'], stats_train_time['ov_std_train_time'],
        stats_train_time['samp_std_train_time'],
        stats_test_time['av_test_time'], stats_test_time['ov_std_test_time'],
        stats_test_time['samp_std_test_time']))

def start(group_log_dir, random_state, logger):
    print('进入main.py 中的start方法！')
    train_loader, test_loader, val_loader, num_classes, n_bands = load_hyper(
        data_path, dataset, spatial_size,
        use_val, train_samples, train_percent,
        batch_size, components=components,
        rand_state=random_state)
    print("n_bands::", n_bands)
    use_cuda = True

    # 创建模型，传入所有结构参数
    model = spikingresformer_hsi_step2(
        num_heads=num_heads,
        T=T,
        num_classes=class_number,
        img_size=spatial_size,
        in_channels=components,
        num_groups=num_groups,
        use_layerscale=use_layerscale
    )
    print(model)
    model = model.cuda()

    # 从模型中动态提取真实配置并记录到本次实验日志
    model_config = extract_model_config(model)
    if model_config is not None:
        logger.info("========== Actual Model Configuration ==========")
        logger.info(f"Embedding dim: {model_config['dim']}")
        logger.info(f"Number of heads: {model_config['heads']}")
        logger.info(f"Effective groups in GSSA: {model_config['effective_groups']}")
        logger.info(f"Length (N): {model_config['lenth']}")
        logger.info("================================================")

    total_params, trainable_params = count_parameters(model)
    logger.info("========== Model Parameters Analysis ==========")
    logger.info(f"Total Parameters: {total_params:,}")
    logger.info(f"Trainable Parameters: {trainable_params:,}")
    logger.info(f"Non-trainable Parameters: {total_params - trainable_params:,}")
    logger.info(f"Parameters per class: {total_params / class_number:,.1f}")
    param_size_mb = total_params * 4 / (1024 ** 2)
    logger.info(f"Estimated Model Size: {param_size_mb:.2f} MB")
    logger.info("================================================")

    optimizer = torch.optim.SGD(model.parameters(), learn_rate, momentum=momentum, weight_decay=weight_decay, nesterov=True)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.2, patience=3)
    criterion = torch.nn.CrossEntropyLoss().cuda()

    best_acc = -1
    train_loss_list = []
    train_acc_list = []
    valid_loss_list = []
    valid_acc_list = []
    train_start_time = time.time()
    for epoch in range(epochs):
        train_loss, train_acc = train(train_loader, model, criterion, optimizer, epoch, use_cuda)
        train_loss_list.append(train_loss)
        train_acc_list.append(train_acc)
        if use_val:
            valid_loss, valid_acc = test(val_loader, model, criterion, epoch, use_cuda)
        else:
            valid_loss, valid_acc = test(test_loader, model, criterion, epoch, use_cuda)
        scheduler.step(train_loss)
        valid_loss_list.append(valid_loss)
        valid_acc_list.append(valid_acc)
        logger.info('Epoch: %03d   Train Loss: %f Train Accuracy: %f   Valid Loss: %f Valid Accuracy: %f' % (
            epoch, train_loss, train_acc, valid_loss, valid_acc))

        if valid_acc > best_acc:
            state = {
                'epoch': epoch + 1,
                'state_dict': model.state_dict(),
                'acc': valid_acc,
                'best_acc': best_acc,
                'optimizer': optimizer.state_dict(),
            }
            torch.save(state, group_log_dir + "/best_model.pth.tar")
            best_acc = valid_acc
    train_end_time = time.time()

    checkpoint = torch.load(group_log_dir + "/best_model.pth.tar")
    best_acc = checkpoint['best_acc']
    model.load_state_dict(checkpoint['state_dict'])
    optimizer.load_state_dict(checkpoint['optimizer'])

    test_start_time = time.time()
    test_loss, test_acc = test(test_loader, model, criterion, epoch, use_cuda)
    test_end_time = time.time()
    logger.info("Final:   Loss: %s  Accuracy: %s", test_loss, test_acc)

    predict_values = np.argmax(predict(test_loader, model, use_cuda), axis=1)
    labels_values = np.array(test_loader.dataset.__labels__())
    classification, confusion, oa, aa, kappa, each_acc = reports(predict_values, labels_values)
    train_time = train_end_time - train_start_time
    test_time = test_end_time - test_start_time
    logger.debug('classification:\n %s\n confusion:\n%s\n ' % (classification, confusion))
    logger.info('AA: %f, OA: %f, kappa: %f\n each_acc: %s' % (aa, oa, kappa, each_acc))
    logger.info("Train time:%s , Test time:%s", train_time, test_time)
    save_acc_loss(train_acc_list, train_loss_list, valid_acc_list, valid_loss_list, group_log_dir)

    return oa, aa, kappa, each_acc, train_time, test_time

if __name__ == '__main__':
    main()